import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Q7_EnricoNavajas {
    public static void main(String[] args) {

        File arquivo = new File("numeros.txt");

        int soma = 0;

        try {
            Scanner tt = new Scanner(arquivo);

            while (tt.hasNextInt()) {

                int numero = tt.nextInt();

                soma += numero;
            }
            tt.close();

        } catch (FileNotFoundException e) {

            System.out.println("Não encontrado!");

        }

        System.out.println("A soma dos é: " + soma);
    }
}