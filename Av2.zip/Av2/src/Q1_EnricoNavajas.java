import java.util.Scanner;
public class Q1_EnricoNavajas {
    public static void main(String[] args) {

        Scanner tt = new Scanner(System.in);

        System.out.println("Digite um número");

        int n1 = tt.nextInt();

        System.out.println("Digite outro número");

        int n2 = tt.nextInt();

        System.out.println("A soma dos números: "+n1+" e "+n2+" é = "+ (n1+n2));

    }
}

