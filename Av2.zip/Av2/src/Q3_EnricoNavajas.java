import java.util.Scanner;

public class Q3_EnricoNavajas {
    public static void main(String[] args) {

        Scanner tt = new Scanner(System.in);

        System.out.print("Digite a quantidade de números: ");

        int quantidade = tt.nextInt();

        int soma = 0;

        for (int i = 1; i <= quantidade; i++) {

            System.out.print("Digite o número " + i + ": ");

            int numero = tt.nextInt();

            soma += numero;
        }

        System.out.println("A soma de todos os números é: " + soma);
    }

}
