import java.util.Scanner;

public class Q2_EnricoNavajas {
    public static void main(String[] args) {
        Scanner tt = new Scanner(System.in);

        System.out.println("Digite o número de entradas");

        int n = tt.nextInt();

        int s = 0;


        for (int i = 0; i < n; i++){

            System.out.println("Digite um valor");

            s += tt.nextInt();

        }

        System.out.println("A soma das entradas "+ n +" é: "+s);

    }

}

