import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Q4_EnricoNavajas {
    public static void main(String[] args) {

        Scanner tt = new Scanner(System.in);

        System.out.print("Digite uma frase: ");

        String input = tt.nextLine();

        StringTokenizer tokenizer = new StringTokenizer(input);

        ArrayList<String> tokens = new ArrayList<String>();

        while (tokenizer.hasMoreTokens()) {

            String token = tokenizer.nextToken();

            if (token.toLowerCase().startsWith("s")) {

                tokens.add(token);
            }
        }

        System.out.println("Palavras que começam com a letra 's': " + tokens);
    }
}
